<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "buindoor";
try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $student_id = $_POST['student_id'];
    $transactionDate = $_POST['transactionDate'];
    $amount = $_POST['amount'];
    $purpose = $_POST['purpose'];
    $transactionMethod = $_POST['transactionMethod'];

    if (!is_numeric($student_id) || strlen($student_id) !== 8) {
        die("Invalid student ID. Please enter a valid integer with exactly 8 digits.");
    }

    if ($transactionMethod === "online") {
        $transactionId = $_POST['transactionId'];
        $paymentMedium = $_POST['paymentMedium'];
        $sql = "INSERT INTO payment (student_id, transactionDate, amount, purpose,transactionId, transactionMethod, paymentMedium)
                VALUES (?, ?, ?, ?, ?,?,?)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$student_id, $transactionDate, $amount, $purpose, $transactionId,$transactionMethod,$paymentMedium]);
    } elseif ($transactionMethod === "offline") {
        $volunteerName = $_POST['volunteerName'];
        $sql = "INSERT INTO payment (student_id, transactionDate, amount, purpose, volunteerName,transactionMethod)
                VALUES (?, ?, ?, ?, ?,?)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$student_id, $transactionDate, $amount, $purpose, $volunteerName,$transactionMethod]);
    }

    //echo "Payment submitted successfully!";
    header("Location: paymentsuccess.html");
    exit;
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
