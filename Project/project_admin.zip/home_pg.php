<?php include("includes/dbcon.php") ?>
<!--  MUST START SESSIION IF USE IT -->
<?php session_start(); ?>

<?php
$validation = $_SESSION['u_name'];
if (!isset($validation)) {
    header('location:login_admin_pg.php?message= Please Login first!');
}

?>


<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>Home- Admin</title>
</head>



<body class="bg-dark">

    <!-- Optional JavaScript; choose one of the two! -->
    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    -->
    <?php include("admin_header.php"); ?>

    <?php

    $stored = [];
    $d_name = $_SESSION['u_name'];
    // Corrected variable name


    // Assuming you have already established a database connection ($con)
    $query = "SELECT * FROM admin WHERE name = ?";
    $stmt = mysqli_prepare($con, $query);


    // Bind parameters
    mysqli_stmt_bind_param($stmt, "s", $d_name); // Corrected variable name


    // Execute query
    mysqli_stmt_execute($stmt);


    // Get result
    $res = mysqli_stmt_get_result($stmt);


    // Handle result
    if ($res) {
        while ($row = mysqli_fetch_assoc($res)) {
            // Process each row
            // echo "Name: " . $row['name'] . "<br>";
            // echo "Email: " . $row['email'] . "<br>";
            // echo "Student ID: " . $row['student_id'] . "<br>";
            // Add more fields as needed
            $stored[] = $row;
        }
    } else {
        // Handle query error
        echo "Error: " . mysqli_error($con); // Example error handling
    }


    // echo var_dump($stored);
    ?>


    <div class="card mt-2 container text-left text-white bg-dark bg-gradient" style="width: 50rem;">
        <div class="card-body text-white bg-dark bg-gradient">
            <h3 class="card-title">User Profile</h3>
            <!-- <p class="card-text">With supporting text below as a natural lead-in to additional content.</p> -->
            <ul class="list-group list-group-flush">


                <li class="list-group-item bg-dark  text-white p-1 font_design">Name: <?php echo $stored[0]['name']; ?> </li>
                <li class="list-group-item bg-dark bg-gradient text-white p-1 font_design">Student ID: <?php echo $stored[0]['student_id']; ?></li>
                <li class="list-group-item bg-dark  text-white p-1 font_design">Email: <?php echo $stored[0]['email']; ?></li>
                <li class="list-group-item bg-dark bg-gradient text-white p-1 font_design">Gsuite Email: <?php echo $stored[0]['gsuite_email']; ?> </li>
                <li class="list-group-item bg-dark  text-white p-1 font_design">Phone: <?php echo $stored[0]['phone']; ?></li>
                <li class="list-group-item bg-dark bg-gradient text-white p-1 font_design">Designation: <?php echo $stored[0]['designation']; ?></li>
                <li class="list-group-item bg-dark  text-white p-1 font_design">Password: <?php echo $stored[0]['password']; ?></li>
            </ul>
            <a id="create_button" href="#" class="btn btn-success mt-5 ">Update Profile</a>
        </div>
    </div>


    <?php include("admin_footer.php"); ?>

</body>

</html>